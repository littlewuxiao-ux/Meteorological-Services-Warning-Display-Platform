# FMSA 登录页改造 · 需求1：全屏 CAS 风格登录页（路线甲）设计文档

- 日期：2026-11-09
- 范围：**仅需求1**（登录页由居中弹框改为浏览器全屏、视觉对齐 CAS 登录页）
- 路线：**路线甲** —— 在 FMSA 内部把登录页重做成全屏，不跳转真实 CAS 页面
- 状态：设计已确认，待实现

---

## 1. 背景与目标

### 1.1 现状

FMSA 是运行在本机 `127.0.0.1:8000` 的 Django 桌面应用，访问入口 `http://localhost:8000/current/`。
未登录时页面中央弹出一个半透明遮罩 + 白色小卡片（400px 宽），卡片内是「请使用丰声扫码登录」+ 二维码 + 状态文字。

CAS 登录页（`https://cas.sf-express.com/cas/login`）的形态是：整页白底、品牌区、**欢迎登录**标题、三个标签页（扫码登录 / 一键登录 / 账密登录）、居中二维码、底部粉色「试试一键登录，更快更安全 / 立即登录」提示条、页脚版权。

### 1.2 目标

把 FMSA 的登录界面从「居中弹框」改成「浏览器全屏页」，视觉形态对齐 CAS 登录页。
**本轮只换皮，不改任何登录逻辑。**

### 1.3 非目标（本轮不做）

- 一键登录（sflink）的实际功能 —— 属需求2
- 账密登录的实际功能 —— 未定，占位
- 「立即登录」按钮的行为 —— 属需求2，本轮置灰
- 底部提示条里的工号回填 —— 属需求2
- 后端 `cas_login.py` / `api/urls.py` / `.env` / `views.py` —— 一行不改

---

## 2. 关键约束

| 约束 | 说明 |
|---|---|
| **id 与 class 不变** | `#login-modal` 必须保留。`showLoginModal` / `hideLoginModal` / `ensureLoginModalOnTop`（main.js:1041/4497/4693）以及 `canDismissModal` 白名单（main.js:1312）全靠它，改了就会连锁回归。 |
| **通用弹窗样式不能动** | `.modal` / `.modal-content` / `.modal-close`（main.css:1371-1413）被其它弹窗共用，只允许覆盖登录专用选择器。 |
| **`#qrcode-container` 会被整块覆盖** | `getQRCode()`（main.js:4530）与 `expireQRCode()`（main.js:4576）都对它做 `innerHTML = ...`。任何放进它内部的装饰元素都会被冲掉。 |
| **z-index 必须保持 40000** | 登录页要盖住实况弹窗（`.metar-popup-overlay` 30000）及其确认框（30001），否则 token 失效时登录页会被未关闭的实况弹窗挡住。 |
| **后端零改动** | 二维码获取 / 轮询 / 校验三段逻辑与 DOM id 一一对应，保持 id 即可复用。 |

---

## 3. 设计

### 3.1 DOM 结构（index.html L1040-1051 整块替换）

```
#login-modal.modal.login-modal
└── .login-page                     全屏 flex 纵向容器（白底、居中）
    ├── .login-brand                品牌区（logo + 系统名 + FMSA）
    ├── .login-card                 登录卡片（标题 + 标签 + 面板）
    │   ├── h2.login-title          欢迎登录
    │   ├── .login-tabs             三个标签按钮
    │   │   └── button.login-tab[data-tab=qr|sflink|pwd]
    │   └── .login-panel[data-panel=qr|sflink|pwd]
    │       ├── qr 面板：.qr-frame > #qrcode-container + .qr-badge（兄弟节点）
    │       │           + .login-hint + #login-status
    │       ├── sflink 面板：.login-placeholder
    │       └── pwd 面板：.login-placeholder
    ├── .login-tip-bar              粉色提示条（文案 + #login-tip-usercode + 置灰按钮）
    └── .login-footer               版权页脚
```

要点：

1. **`#qrcode-container` 内部保持只有一个 `<img>`**（与现状一致），丰声角标 `.qr-badge` 放在 `.qr-frame` 里做绝对定位叠加。
2. **不使用 `.modal-content` 类**，改用 `.login-page`，避免继承 `margin:5% auto / width:80% / max-width:1200px / border-radius:8px / max-height:80vh`。
3. 保留的 id：`#qrcode-container`、`#qrcode-image`、`#login-status`（后端与轮询逻辑依赖）。
4. 新增的 id：`#login-tip-usercode`（需求2 回填工号）、`#login-oneclick-btn`（需求2 接线，本轮 `disabled`）。

### 3.2 样式（main.css L3184-3223 整段替换）

- 原注释保留（说明 z-index 40000 的理由）。
- `.login-modal`：半透明遮罩 → 纯白全屏（`background:#fff; overflow:hidden; z-index:40000`）。
- 新增 `.login-page` / `.login-brand` / `.login-card` / `.login-title` / `.login-tabs` / `.login-tab` / `.login-panel` / `.qr-frame` / `.qr-badge` / `.login-hint` / `.login-placeholder` / `.login-tip-bar` / `.login-tip-btn` / `.login-footer`。
- 改写 `.qrcode-container`（去掉 `display:inline-block`，改块级 + 8px 内边距 + 浅边框）、`.login-status`（去掉 `margin-top:15px` 改 8px、居中）。
- 删除 `.login-content` / `.login-container` / `.login-container h3`（新结构不再使用）。
- 配色对齐 CAS：主色 `#e2231a`，正文 `#1f2d3d`，次要文字 `#6b7280` / `#8a94a6`，浅边框 `#e6e9ee` / `#eef1f5`，提示条底色 `#fff1f2` / 边框 `#ffd9dc` / 文字 `#b42318`。

### 3.3 交互（main.js 新增 1 个函数 + 改 1 行）

新增 `switchLoginTab(tab)`：纯 class 切换（`.login-tab.active` 与 `.login-panel.active`），**不取码**。
挂在 `window.switchLoginTab`，与既有 `window.handleQRCodeClick`（main.js:4608）同一套路，供 HTML 内联 `onclick` 调用。

`showLoginModal()` 在 `loginModal.style.display = 'block';` 之后插入一行 `switchLoginTab('qr');`，其余不动。

**行为不变性**：`getQRCode()` 仍由 `showLoginModal()` 无条件调用，因此"每次打开登录页都重新取码 + 重启轮询"的既有行为完全保留。
`switchLoginTab` 之所以不取码，是因为取码逻辑一旦搬进来就会出现「首次打开双次取码」或「重登复用过期二维码、轮询不重启」两类回归。标签切换只负责显隐。

所有进入登录页的路径（token 失效 `showTokenInvalidError`、登出、`handleRelogin`、`initCurrentModeAuth` 兜底）都经由 `showLoginModal()`，因此都会自动复位到「扫码登录」标签。

### 3.4 本轮占位策略（已确认）

| 元素 | 本轮 |
|---|---|
| 「一键登录」标签 | 渲染，面板内显示「一键登录将在后续版本接入」灰字 |
| 「账密登录」标签 | 渲染，面板内显示「账密登录将在后续版本接入」灰字 |
| 底部提示条 | 渲染，文案齐全 |
| 「立即登录」按钮 | 渲染，`disabled`（`:disabled` 样式为浅红） |
| `#login-tip-usercode` | 渲染为空 |

选择"显示占位"的理由：结构与 CAS 一次对齐，需求2 接线时只改面板内容与按钮行为，不再动 DOM 结构。

---

## 4. 改动文件清单

| 文件 | 位置 | 改动 |
|---|---|---|
| `fmsa_django/templates/web/index.html` | L1040-1051 | 整块替换（12 行 → 约 48 行） |
| `fmsa_django/static/css/main.css` | L3184-3223 | 整段替换（40 行 → 约 45 行） |
| `fmsa_django/static/js/main.js` | L4496 附近 | 新增 `switchLoginTab` + `window.switchLoginTab` |
| `fmsa_django/static/js/main.js` | L4497-4503 | `showLoginModal()` 内插 1 行 |

不改：`cas_login.py`、`api/urls.py`、`api/views.py`、`.env`、`.env.example`、`base.html`、`.modal` 系列样式。

---

## 5. 风险与回滚

| 风险 | 应对 |
|---|---|
| 误改通用 `.modal` / `.modal-content` 影响其它弹窗 | 只覆盖登录专用选择器；`.modal` 系列一行不动 |
| 角标被 `innerHTML` 冲掉 | 角标放 `.qr-frame` 兄弟节点，不放 `#qrcode-container` 内 |
| 标签切换导致取码行为变化 | `switchLoginTab` 不取码；`getQRCode()` 调用点保持原样 |
| 登录页被实况弹窗遮挡 | `.login-modal` 的 `z-index:40000` 原样保留 |
| 全屏后背景页面仍可滚动 | `.login-page` 自身 `overflow:auto`，`.login-modal` `overflow:hidden`；modal 为 `position:fixed` 全视口覆盖，背景滚动不可见 |

**回滚**：改动集中在 3 个文件、4 处。动手前对每个文件各留一份 `.bak`，回滚 = 覆盖回去。

---

## 6. 验收

1. `python manage.py check` 通过（FMSA 目录下执行）。
2. 打开 `http://localhost:8000/current/`，未登录时看到**全屏**白底登录页，非居中弹框。
3. 二维码正常显示、120 秒过期后出现「二维码已过期 / 点击获取」且可点击重取。
4. 手机扫码后能正常登录、进入主界面（既有链路不受影响）。
5. 点击「一键登录」「账密登录」标签能切换面板并显示占位文案；点回「扫码登录」二维码仍在。
6. 点遮罩 / 按 ESC **不能**关闭登录页（`canDismissModal` 白名单行为保持）。
7. token 失效（如重启服务端）时登录页正常弹出且**不被实况弹窗遮挡**。
8. 登出后回到登录页，且标签复位到「扫码登录」。

---

## 7. 后续（需求2，待定）

需求2「sflink 一键登录」的改动点已初步梳理，但**卡在一个未决问题**：用 sflink 的 ticket 换 FMSA 业务 token 走哪条路——

1. sflink → CAS ST → 复用 FMSA 现有的 `SF_CAS_VALIDATE_URL`（推荐）
2. 照搬 MCP 的完整 4 步（含 `sfa-wgw-inn` 网关）
3. 先实际探测 sflink 接口（需要用户授权发起真实认证调用）

该问题确认后再出需求2 的设计文档。本轮不受影响。
