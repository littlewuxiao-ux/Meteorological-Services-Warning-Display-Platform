# 需求2 设计：FMSA 一键登录（sflink 链路，浏览器取票据 + 服务端换票）

- 日期：2026-11-09
- 范围：`D:\application-run\cailiao\FMSA-1\FMSA`
- 状态：已实施（2026-11-09）
- 关联：`2026-11-09-fmsa-login-page-fullscreen-design.md`（需求1，已实施）

## 1. 背景与目标

需求1 已把登录弹窗改造成全屏 CAS 风格页，底部保留了「试试一键登录，更快更安全 / 立即登录」提示条，按钮处于 `disabled` 占位状态。

本需求把该按钮接活：**用户点一下即可登录，不必掏手机扫码**。

判定标准：点击按钮后，前端拿到与扫码登录**同形**的 `{token, userCode}`，走同一条落地路径。扫码登录必须原样保留，作为一键登录不可用时的兜底。

## 2. 实测依据

四步链路已在 2026-11-09 用真实请求跑通并拿到有效 token。

### 2.1 链路

| 步骤 | 请求 | 结果 |
|---|---|---|
| 1 | `GET {SF_SFLINK_BASE_URL}/api/public/clientlogin/auth_login?app_id=&time_stamp=&sole_id=` | JWT ticket，`sub` = 工号，`exp - iat` = 180 秒 |
| 2 | `GET {SF_CAS_BASE_URL}/login?service={SF_CAS_SERVICE_URL}` | 正则取到 `name="lt" value="..."`，同时种下 cookie |
| 3 | `POST` 同 URL，表单见下 | **HTTP 302**，`Location` 含 `?ticket=ST-...` |
| 4 | `POST {SF_CAS_VALIDATE_URL}`，JSON 见下 | `{"success":true,"obj":{"token":"INN_A3_...","userId":"422578"}}` |

第 3 步表单：

```
username         = <工号>
password         = active123.
lt               = <第 2 步取到>
verifyType       = sflinkTicket
dynamicPassword  = <第 1 步的 ticket>
_eventId         = submit
qrcodeId         = (空)
```

第 4 步 JSON：

```
st        = <第 3 步的 ST>
service   = {SF_CAS_SERVICE_URL}
appKey    = {SF_CAS_APP_KEY}
appSecret = {SF_CAS_APP_SECRET}
```

### 2.2 四个关键事实

**事实一：`service` 必须是 `https://sfa-gwgw-inn.sf-airlines.com:8443`。**
传裸主机名会命中 CAS 的「安全级别更高，需二次校验」分支，第 3 步拿不到 ST。该值**不是** `SF_CAS_SERVICE_ID`（后者是裸主机名，仅供 `getConfig` 当 `serviceId` 用）。

**事实二：密码字段不校验。**
固定串 `active123.`、真实密码、**故意写错的密码**都能通过，只有空值被卡住。因此 FMSA **不需要保存任何密码**，照抄 CAS 自身 `loginFsnext()` 里那个写死的 `active123.` 即可。

**事实三：ST 一次性，180 秒内必须消费；但票据本身在 180 秒内可重复使用。**
每次提交都会拿到**新的 ST**，所以「ST 一次性」只在单次流程内成立。实测同一张票据连换两次 token 都成功。这决定了：四步必须在**同一个请求内**串完；同时票据是一个 180 秒有效的 bearer 凭据，**不能落日志**。

**事实四：票据的身份由请求来源决定，不由参数决定。**
`auth_login` 只带 `app_id` / `time_stamp` / `sole_id` 三个参数，**没有任何设备标识**。身份只能来自请求的源 IP。实测：本机裸请求（无 cookie）即得本机工号。

事实四是本方案架构的决定性依据，见 3.1。

## 3. 方案设计

### 3.1 架构：第 1 步必须在浏览器，第 2-4 步在服务端

由事实四推出：

- **浏览器**取票据 → 拿到「用户本机」的丰声身份。桌面版=本人，Web 版=访问者本人。
- **服务端**取票据 → 拿到「服务器」的身份。Web 部署下所有用户会被登成同一人。

所以第 1 步必须放在浏览器。第 2-4 步是纯协议转换，与「谁发起的」无关，放服务端还能让 `appKey`/`appSecret` 不下发前端。

```
浏览器（用户机器）                        FMSA 服务器
   │                                          │
   │ ① GET sflinksso auth_login               │   源 IP = 用户机器 → sub = 用户工号
   │    ← ticket                              │
   │                                          │
   │ ② POST /api/auth/one-click-login/        │
   │    {ticket}                              │
   │                                          │ ③ GET CAS login?service=… → lt
   │                                          │ ④ POST verifyType=sflinkTicket
   │                                          │    + dynamicPassword=<ticket> → ST
   │                                          │ ⑤ POST cas3.0 → token
   │    ← {token, userCode}                   │
```

**这个切分在桌面模式下同样成立**：浏览器与服务端在同一台机器，源 IP 相同，拿到的身份与「服务端取票据」完全一致。

**因此不设来源限制。** 每个调用者带的都是自己的票据、换回的都是自己的 token，远程访问是正常用法。早期版本曾加过「仅允许回环地址」守卫，那是建立在「服务端取票据」这个错误前提上的，已移除。

### 3.2 新增 `fmsa_django/api/sflink_login.py`

约 200 行。**不包含取票据的逻辑**——票据由前端传入。

| 函数 | 职责 |
|---|---|
| `_decode_user_code(ticket)` | 解 JWT payload 的 `sub` 得工号 |
| `get_cas_lt(session, service)` | 第 2 步，返回 `(login_url, lt, hidden_fields)` |
| `submit_cas_login(...)` | 第 3 步，不跟随重定向，从 `Location` 抓 `ST-` |
| `_fetch_routing()` | 取 `getConfig` 的 `routing` 作为请求头，失败返回 `None` |
| `exchange_token(st, service, user_code)` | 第 4 步，调网关换 token |
| `one_click_login(ticket)` | 编排 2-4 步，返回 `(token, user_code)` |

**关键约束：本模块使用自己的 `requests.session()`，绝不复用 `cas_login.session`。**
`cas_login.reset_cas_http_session()` 会在每次扫码前清空那个全局会话，共用会让两条流程互相踩 cookie。

同理 `_fetch_routing()` 刻意不调 `cas_login.get_config()`（那会往扫码会话里种 Set-Cookie），改用一次性请求。

### 3.3 `cas_login.py` 改动

第 119-120 行写死的 `"mtws_foc2"` / `"mtwsFoc2#123"` 替换为 `gateway_credentials()`（从 `.env` 读取）。

**纯取值替换**：`validate_login` 的入参、出参、调用时序、请求体结构全部不变，扫码路径行为零变化。收益是密钥在代码里不再有第二份拷贝。

### 3.4 新增接口 `POST /<mode>/api/auth/one-click-login/`

- 视图 `one_click_login(request, time_mode='current')`，与 `check_login_status` 同形
- 仅 `current` 模式，非 `current` 返回 400
- 从请求体读 `ticket`；缺失返回 400
- 返回 `{"success": true, "data": {"token": ..., "userCode": ...}}`；换票失败返回 200 + `{"success": false, "error": ...}`
- **token 不落服务端 session**——现有扫码路径也是直接返给前端、由前端存 localStorage
- **票据不落日志**

### 3.5 `.env` 新增键

```
SF_CAS_BASE_URL=https://cas.sf-express.com/cas
SF_CAS_SERVICE_URL=https://sfa-gwgw-inn.sf-airlines.com:8443
SF_SFLINK_BASE_URL=https://sflinksso.sf-express.com:54339
SF_SFLINK_APP_ID=<36 字符的客户端标识>
SF_CAS_APP_KEY=<从 cas_login.py 迁出>
SF_CAS_APP_SECRET="<从 cas_login.py 迁出>"
```

**不新增密码键**，依据是事实二。

`SF_SFLINK_BASE_URL` / `SF_SFLINK_APP_ID` 由 `web/views.py` 读入 context，再注入页面（见 3.6）——它们是前端要用的配置，不是服务端凭据。

**注意**：`SF_CAS_APP_SECRET` 的值含 `#`，必须带引号，否则会被 `.env` 解析器当行内注释截断。

### 3.6 前端改动

**`web/views.py`**：`index` 视图 context 增加 `sflink_base_url` / `sflink_app_id`。

**`index.html`**：在既有的 `window.xxx` 注入块里加两行：

```js
window.sflinkBaseUrl = '{{ sflink_base_url }}';
window.sflinkAppId = '{{ sflink_app_id }}';
```

**`main.js`**：

1. 抽取 `handleLoginSuccess(token, userCode)`：把 `check_login_status` 成功分支里从 `writeStoredAuth` 到 `loadInitialData` 的约 15 行原样搬进来，扫码路径改为调用它。**纯提取**，行为不变。
2. 新增 `stopQRCodePolling()`。
3. 新增 `fetchSflinkTicket()`：调 sflinksso 取票据，返回 Promise。
4. 新增 `doOneClickLogin()`：`fetchSflinkTicket()` → `POST {ticket}` → 成功走 `handleLoginSuccess`，失败提示并留在扫码页。
5. `showLoginModal()` 内复位一键登录按钮（见下）。

**`showLoginModal()` 里的按钮复位是必须的。**
登录成功后按钮停在 `disabled` + 「登录中...」。若不复位，用户登出后重新打开登录页，按钮会永久卡在禁用态，一键登录再也点不动。实测确认过这个缺陷。

## 4. 改动清单

| 文件 | 动作 |
|---|---|
| `fmsa_django/api/sflink_login.py` | 新增 |
| `fmsa_django/api/cas_login.py` | 加 `gateway_credentials()`；硬编码凭据改为读 `.env` |
| `fmsa_django/api/views.py` | 新增 `one_click_login` 视图 |
| `fmsa_django/api/urls.py` | 新增 `auth/one-click-login/` |
| `fmsa_django/web/views.py` | context 增加两个 sflink 配置项 |
| `fmsa_django/static/js/main.js` | 抽 `handleLoginSuccess` + 新增 3 个函数 + 按钮复位 |
| `fmsa_django/templates/web/index.html` | 注入两个配置项；按钮去 `disabled` 绑事件 |
| `FMSA/.env` | 新增 6 个键 |

**不改**：`access_control.py`、`auth_broker_client.py`、任何迁移文件、任何数据库结构。

## 5. 风险与对策

| 风险 | 说明 | 对策 |
|---|---|---|
| 票据是 180 秒有效的 bearer 凭据 | 持有票据即可换 token，且可重复换 | 票据不落日志；`log_cas_api_request` 只记 URL 与工号 |
| 依赖外网连通 | `sflinksso.sf-express.com:54339` 与 `cas.sf-express.com` 任一不通即失败 | 扫码入口始终保留，失败时明确提示并停留扫码页 |
| 中途失败无法续跑 | ST 一次性，四步必须连着走完 | 整个流程同步串行、单请求内完成 |
| 跨域取票依赖 sflinksso 的 CORS | 实测 `Access-Control-Allow-Origin: *`，预检 200 | 已在真实浏览器验证通过 |
| 凭据外置引入回归 | `validate_login` 改动波及扫码路径 | 改动限定为取值替换，且已证明取值与原字面量逐字节一致 |

### 一个未验证的假设

服务端拿**用户机器取的**票据去 CAS 换 ST（第 ④ 步）——CAS 是否校验提交方 IP 与票据来源一致，本机无法验证（改不了源 IP）。

从 CAS 页面自身做法看不像是会校验：`deviceid` 只被存进 cookie `sflinkDeviceId` 供后续用，提交表单时并未回传。但这是推断。

**真正上服务器前必须拿两台机器验一次。** 若 CAS 确实绑 IP，这条路走不通，只能退回「跳转真实 CAS 登录页」。

## 6. 边界（本轮不做）

- 不做 `fsnext` 模式（需本机安装丰声Next 客户端）
- 不做多账号选择（CAS 页面有 next/link 双通道时的选择 UI）
- 不做服务端缓存票据或复用 ST
- 不在 `#login-tip-usercode` 展示工号
- 不做失败自动重试

## 7. 验证方式

1. **静态**：`py_compile` + `node --check main.js`
2. **接口级**：取票据 → POST → 断言 `success=true` 且 `userCode` 与票据 `sub` 一致
3. **边界**：空 body / 空 ticket → 400
4. **回归**：扫码入口 `get-qrcode` 正常
5. **浏览器实测**：真实点击按钮走完整流程，断言 token 落 localStorage、登录页隐藏

## 8. 实施记录（2026-11-09）

分两阶段完成。第一阶段按「服务端取票据」实现，第二阶段按 3.1 的分析改为「浏览器取票据」。

### 验证结果

| 项 | 方式 | 结果 |
|---|---|---|
| 语法 | `py_compile` × 4 + `node --check main.js` | 通过 |
| 边界 | 空 body / 空 ticket POST | 均 HTTP 400「缺少 sflink 票据」 |
| 取票据 | 浏览器内调 `fetchSflinkTicket()` | 返回 540 字符 JWT |
| 换票 | 票据 POST 给后端 | HTTP 200，`userCode=422578`，token 52 字符，与票据 `sub` 一致 |
| 浏览器实测 | 真实点击「立即登录」 | `settled=logged-in`，token `INN_A3_…` 落 localStorage，登录页 `display:none` |
| 按钮复位 | 登出后重开登录页 | 按钮从 `disabled/登录中...` 恢复为可用/「立即登录」 |
| 凭据一致性 | 对比 `gateway_credentials()` 与原字面量 | 6 个键全部一致 |
| 硬编码清除 | 搜索 `mtws_foc2` / `mtwsFoc2#123` | `cas_login.py` 中已清除 |
| 扫码入口回归 | POST `get-qrcode` | HTTP 200，二维码 base64 100464 字符 |

### 未覆盖

`validate_login` 的**完整**扫码换票链路未实测——需要真人用手机扫一次码。风险很低（纯取值替换，取值已证明逐字节一致）。

### 备份

- `.bak-oneclick-20261109\` —— 第一阶段改动前原件（6 个文件）
- `.bak-oneclick-split-20261109\` —— 第二阶段（分体结构）改动前原件（5 个文件）
