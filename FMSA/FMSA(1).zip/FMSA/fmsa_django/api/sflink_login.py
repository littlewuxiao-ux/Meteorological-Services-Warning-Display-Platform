# -*- coding: utf-8 -*-
"""一键登录：sflink 票据 -> CAS 票据(ST) -> FMSA token。

★ 票据由**浏览器**取，不由服务端取 —— 这是本模块最关键的设计约束。

sflinksso 的 auth_login 接口只带 app_id / time_stamp / sole_id 三个参数，
没有任何设备标识，身份完全由请求的来源决定。因此：

  * 浏览器取票据 -> 拿到「用户本机」的丰声身份（桌面版=本人，Web 版=访问者本人）
  * 服务端取票据 -> 拿到「服务器」的身份，Web 部署下会把所有人都登成同一人

所以第 1 步必须在浏览器里做。本模块只负责第 2-4 步：拿浏览器递上来的票据
去 CAS 换 ST，再拿 ST 去网关换业务 token。这三步是纯协议转换，与「谁发起的」
无关，放服务端还能让 appKey/appSecret 不下发前端。

链路（2026-11-09 实测打通）：
  1. （浏览器）GET {SF_SFLINK_BASE_URL}/api/public/clientlogin/auth_login -> JWT 票据
  2. GET  {SF_CAS_BASE_URL}/login?service={SF_CAS_SERVICE_URL}   -> lt + cookie
  3. POST 同一地址，verifyType=sflinkTicket                       -> 302 ?ticket=ST-...
  4. POST {SF_CAS_VALIDATE_URL}                                   -> obj.token

三个容易踩的点：

  * service 必须是 SF_CAS_SERVICE_URL（带 scheme 和端口）。传裸主机名会命中
    CAS 的「安全级别更高，需二次校验」分支，第 3 步拿不到 ST。
    它与 SF_CAS_SERVICE_ID 语义不同：后者是裸主机名，只给 getConfig 当
    serviceId 用，两者不可互换。

  * 密码字段在 sflinkTicket 路径下不参与校验。实测：固定串、真实密码、
    故意写错的密码都能通过，只有空值会被表单卡住。因此本模块不保存任何
    密码，直接沿用 CAS 自身 loginFsnext() 里的那个固定串。

  * 四步必须连着走完。ST 一次性且只有 180 秒寿命，中途失败无法续跑。
"""

import base64
import json
import re
from urllib.parse import unquote

import requests

from utils.cas_api_log import log_cas_api_request
from utils.sf_env import require

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

_TIMEOUT = 10

# 密码不参与校验，照抄 CAS 自身 loginFsnext() 的固定串即可，无需进 .env。
_CAS_FORM_PASSWORD = 'active123.'

_LT_RE = re.compile(r'name="lt"\s+value="([^"]+)"')
_HIDDEN_RE = re.compile(r'<input[^>]*type="hidden"[^>]*name="([^"]+)"[^>]*value="([^"]*)"')
_ST_RE = re.compile(r'ticket=(ST-[^&]+)')


class SflinkLoginError(Exception):
    """一键登录失败。message 面向用户，可直接提示。"""


def _decode_user_code(ticket):
    """从 JWT payload 里取 sub（工号）。"""
    try:
        payload = ticket.split('.')[1]
        payload += '=' * (-len(payload) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload).decode('utf-8'))
    except Exception as exc:
        raise SflinkLoginError('无法解析 sflink 票据') from exc
    user_code = str(data.get('sub') or '').strip()
    if not user_code:
        raise SflinkLoginError('sflink 票据里没有工号')
    return user_code


def get_cas_lt(session, service):
    """第 2 步：打开 CAS 登录页取 lt。返回 (login_url, lt, hidden_fields)。"""
    login_url = require('SF_CAS_BASE_URL').rstrip('/') + '/login'
    try:
        response = session.get(login_url, params={'service': service},
                               headers={'User-Agent': _UA}, timeout=_TIMEOUT)
    except Exception as exc:
        raise SflinkLoginError('无法打开 CAS 登录页') from exc

    html = response.text or ''
    matched = _LT_RE.search(html)
    if not matched:
        raise SflinkLoginError('CAS 登录页未返回 lt（service 可能不被识别）')
    return login_url, matched.group(1), dict(_HIDDEN_RE.findall(html))


def submit_cas_login(session, login_url, lt, hidden_fields, user_code, ticket):
    """第 3 步：提交登录表单，从 302 的 Location 里取 ST。"""
    form = dict(hidden_fields)
    form.update({
        'username': user_code,
        'password': _CAS_FORM_PASSWORD,
        'lt': lt,
        'verifyType': 'sflinkTicket',
        'dynamicPassword': ticket,
        '_eventId': 'submit',
        'qrcodeId': '',
    })
    try:
        response = session.post(login_url, data=form,
                                headers={'User-Agent': _UA, 'Referer': login_url},
                                allow_redirects=False, timeout=_TIMEOUT)
    except Exception as exc:
        raise SflinkLoginError('提交 CAS 登录失败') from exc

    location = response.headers.get('Location') or ''
    matched = _ST_RE.search(location)
    if not matched:
        raise SflinkLoginError('CAS 未返回票据（ST）')
    return unquote(matched.group(1))


def _fetch_routing():
    """取 getConfig 的 routing，作为换票请求头。

    刻意不复用 cas_login.get_config()：那个函数走的是扫码流程的全局 session，
    会把 CAS 的 Set-Cookie 种进扫码会话。这里用一次性请求，互不干扰。
    拿不到时返回 None —— 实测不带 routing 也能换到 token。
    """
    try:
        response = requests.post(
            require('SF_CAS_CONFIG_URL'),
            json={'serviceId': require('SF_CAS_SERVICE_ID')},
            headers={'User-Agent': _UA},
            timeout=_TIMEOUT,
        )
        return (response.json() or {}).get('routing')
    except Exception:
        return None


def exchange_token(st, service, user_code):
    """第 4 步：拿 ST 到网关换 FMSA token。

    与扫码路径走同一个网关地址、同一对密钥（都从 .env 取），
    所以换回来的 token 形状与扫码完全一致。
    """
    from .cas_login import gateway_credentials

    headers = {'User-Agent': _UA}
    routing = _fetch_routing()
    if routing:
        headers['routing'] = routing

    app_key, app_secret = gateway_credentials()
    payload = {'st': st, 'service': service, 'appKey': app_key, 'appSecret': app_secret}

    validate_url = require('SF_CAS_VALIDATE_URL')
    log_cas_api_request(validate_url, user_id=user_code, has_token=False)
    try:
        response = requests.post(validate_url, headers=headers, json=payload,
                                 timeout=_TIMEOUT)
        body = response.json()
    except Exception as exc:
        raise SflinkLoginError('换取登录凭证失败') from exc

    token = str(((body or {}).get('obj') or {}).get('token') or '').strip()
    if not token:
        raise SflinkLoginError(str((body or {}).get('errorMessage') or '换取登录凭证失败'))
    return token


def one_click_login(ticket):
    """拿浏览器递上来的 sflink 票据换 FMSA token。

    ticket 由前端调用 sflinksso 取得，必须是用户本机发起的请求 ——
    本模块不再自己取票据，否则 Web 部署下会拿到服务器的身份。

    成功返回 (token, user_code)，失败抛 SflinkLoginError。
    """
    ticket = str(ticket or '').strip()
    if not ticket:
        raise SflinkLoginError('缺少 sflink 票据')

    service = require('SF_CAS_SERVICE_URL')
    user_code = _decode_user_code(ticket)

    session = requests.session()
    try:
        login_url, lt, hidden_fields = get_cas_lt(session, service)
        st = submit_cas_login(session, login_url, lt, hidden_fields, user_code, ticket)
        token = exchange_token(st, service, user_code)
        return token, user_code
    finally:
        try:
            session.close()
        except Exception:
            pass
