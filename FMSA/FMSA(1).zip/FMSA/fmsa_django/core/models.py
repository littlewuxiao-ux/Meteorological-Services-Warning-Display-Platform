"""模型已按库拆到 config_db / runtime_db / access_db。这里只转接旧引用。"""

from access_db.models import AccessSetting
from config_db.models import (
    AirportAlertThresholds,
    AirportInfo,
    AirportPrefixArea,
    AirportTafImportConfig,
    Carrier,
    DataRefreshTimer,
    HistoryStatsConfig,
    StyleConfig,
    PopupSettings,
    RadarAlertConfig,
    SystemConfig,
    TrendAlertConfig,
    WeatherAlertLevels,
    WeatherTypeInfo,
)
MapStyleConfig = StyleConfig

from runtime_db.models import (
    AircraftParkingInfo,
    AirportRadarAlert,
    AirportTrendAlert,
    RadarJobRun,
    RadarTileIndex,
    WxmsgImportAlert,
)

__all__ = [
    'AccessSetting',
    'AircraftParkingInfo',
    'AirportAlertThresholds',
    'AirportInfo',
    'AirportPrefixArea',
    'AirportRadarAlert',
    'AirportTafImportConfig',
    'AirportTrendAlert',
    'Carrier',
    'DataRefreshTimer',
    'HistoryStatsConfig',
    'MapStyleConfig',
    'StyleConfig',
    'PopupSettings',
    'RadarAlertConfig',
    'RadarJobRun',
    'RadarTileIndex',
    'SystemConfig',
    'TrendAlertConfig',
    'WeatherAlertLevels',
    'WeatherTypeInfo',
    'WxmsgImportAlert',
]
